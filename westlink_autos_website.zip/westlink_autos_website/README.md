# Westlink Auto's website starter

## Included
- Responsive dealership landing page and vehicle catalogue
- Search, brand/category filters and price sorting
- Vehicle detail modal with photo thumbnails
- WhatsApp enquiry and booking handoff
- Google Maps directions link
- Admin inventory UI for a local-browser demonstration

## Important before publishing
This is a front-end starter, not a production-ready commerce system. The admin inventory demo stores data in the current browser only. Customer registration/login, secure admin access, shared car inventory/image uploads, real booking records, customer reviews and payment processing are NOT connected yet.

Do not collect passwords or payment details with this static page. For production, connect:
- Supabase Auth for customer/admin authentication
- Supabase Postgres for vehicles, bookings and reviews
- Supabase Storage for vehicle photo galleries
- A server-side Netlify Function or Vercel Function for Paystack transaction initialization and verification

Never put a Paystack secret key, Supabase service-role key, or other private token in browser JavaScript or HTML.

## Client details used
- Business: Westlink Auto's
- Email: Westlinkautos@gmail.com
- Address: Isolo Okeafa, Ejigbo Road, beside Mobile Fuel Station, Lagos, Nigeria
- Phone/WhatsApp in this starter: +2348162860678 — confirm this number with the client before launch.
- Brands: Volkswagen, Audi, Bentley, Porsche

## Deploy
Upload `index.html` to your GitHub repository root. Netlify and Vercel can both deploy the same repository. For production, configure the backend and environment variables separately in each host.
